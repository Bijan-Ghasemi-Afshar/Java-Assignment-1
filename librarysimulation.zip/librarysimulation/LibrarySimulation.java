/*
* A program that generates a number of library books
* and simulates a number of library events
*/
package librarysimulation;

import java.util.Random;
import java.util.Scanner;

/**
 * 10/11/2015
 * @author Bijan Ghasemi Afshar ( 100125463 )
 */
public class LibrarySimulation {
    
    
    /**
     * A method to generate a collection of LibraryBook objects to use as
     * test data in your simulation
     * @return an array of LibraryBook objects     
     */
    public static LibraryBook [] generateBookStock(){
        String [] authorsList =
        { "Lewis and Loftus", "Mitrani", "Goodrich",
            "Lippman", "Gross", "Baase", "Maclane", "Dahlquist",
            "Stimson", "Knuth", "Hahn", "Cormen and Leiserson",
            "Menzes", "Garey and Johnson"};
        String [] titlesList =
        { "Java Software Solutions", "Simulation",
            "Data Structures", "C++ Primer", "Graph Theory",
            "Computer Algorithms", "Algebra", "Numerical Methods",
            "Cryptography","Semi-Numerical Algorithms",
            "Essential MATLAB", "Introduction to Algorithms",
            "Handbook of Applied Cryptography",
            "Computers and Intractability"};
        int [] pagesList = {832, 185, 695, 614, 586, 685, 590, 573, 475,
            685, 301, 1175, 820, 338};
        int n = authorsList.length;
        
        LibraryBook [] bookStock = new LibraryBook[n];
        for(int i = 0; i < n; i++){
            bookStock[i] = new LibraryBook(authorsList[i],
                    titlesList[i], pagesList[i]);
        }
// set library classification for half of the LibraryBooks
        for(int i = 0; i < n; i=i+2){
            bookStock[i].setClassification("QA" + (99 - i));
        }
// set approx. two thirds of LIbraryBooks in test data as
// lending books
        for(int i = 0; i < 2*n/3; i++){
            bookStock[i].setAsForLending();
        }
// set approx. one third of LibraryBooks in test data as
// reference-only
        for(int i = 2*n/3; i < n; i++)
            bookStock[i].setAsReferenceOnly();
        
        /***************** EXTRA TO THE GIVEN CODE ******************
           * Creating a library book object with the same values as a
           * book from book stock
           * calling the object prints a description of the 
           * book from the book stock
           * Related to the toString method
           */
        for(int i = 0; i < n; i++){
            LibraryBook courseText = bookStock[i];
            System.out.println(courseText);
        }
                    
        return bookStock;
        
    } // END of the generate METHOD
    
    
    
    /**
     * @param bookStock the stock of LibraryBooks in the library
     * @param numberOFevents the size of the events table to be
     * @return generated table of events generated during
     * the simulation
     */
    public static String [] runSimulation(LibraryBook [] bookStock,
            int numberOFevents)
    {
        System.out.println("\n*******************************************\n");
        
        // Creating a random and a number of event objects
        Random random = new Random ();
        String [] event = new String[numberOFevents+1];
        event[0] = null;
        
        
        // Generating events based on the library book status and classification
        for(int j = 1; j < numberOFevents+1; j++){
            
            // Getting a random number in order to get a random library book
            int randomNumber = random.nextInt(13);                     
            
            //***************************
            // For getting a description of the random selected library book 
            // uncomment the two following lines of code                                 
//            LibraryBook courseText = bookStock[randomNumber];
//            System.out.println(courseText);
            //****************************
            
            // If a library book has no calssification user needs to
            // give that book a proper classification            
            if(bookStock[randomNumber].getLibraryClassification() == null)
            {
                String bookClass = null;
                Scanner scan = new Scanner (System.in);
                do{
                    System.out.print("This book is currently unclassified"
                            + ", give it its proper classification: ");
                            
                    bookClass = scan.next();
                }
                // If the given classification by the user is not valid 
                // they are asked to give another classification
                while(bookStock[randomNumber].setClassification(bookClass) != true);
                
                event[j] = "BOOK IS CLASSIFIED";
            }
            else
            {
                // Getting a random number ( 0-1 ) to determine whether  
                // a library book is return or there is reservation request for it
                int randNum = 0;
                randNum = random.nextInt(2);
                
                // Determining the type of an event based on the status of
                // a library book and other conditions
                switch (bookStock[randomNumber].getCurrentStatus())
                {
                    case REFERENCE_ONLY: event[j] = "REFERENCE ONLY BOOK";
                    break;
                        
                    case AVAILABLE_FOR_LENDING: event[j] = "BOOK IS LOANED OUT";
                    bookStock[randomNumber].borrowBook();
                    break;
                        
                    case ON_LOAN:
                        
                        // If the random number is 0 the library book is returned
                        if(randNum == 0)
                        {
                            event[j] = "BOOK IS RETURNED ";
                            bookStock[randomNumber].returnBook();
                        }
                        
                        // If the random number is 1 there is a reservation
                        // request for the library book
                        if(randNum == 1 && bookStock[randomNumber].reserveBook() == true)
                        {
                            event[j] = "RESERVATION PLACED FOR ON-LOAN BOOK";
                            break;
                        }
                        else if(randNum == 1 && bookStock[randomNumber].reserveBook() == false) {
                            event[j] = "BOOK IS ON-LOAN BUT CANNOT BE RESERVED";
                        }
                        break;
                }
            }
            
            // Printing the Evnts
            System.out.println(j+" "+bookStock[randomNumber].totalOnLoanBooks+" "+
                    bookStock[randomNumber].getLibraryClassification()+" "+event[j]);                      
            
            
        }
        return event;
    } // END of the run METHOD
    
        
    public static void main(String[] args) {
        
//        Running the simulation with 200 events **************  <==
        runSimulation( generateBookStock(), 200 );
        
    } // END of the main METHOD
    
} // END of the CLASS
