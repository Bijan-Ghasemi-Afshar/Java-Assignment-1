/*
* A class which represent a library book
*/
package librarysimulation;

/**
 * 10/11/2015
 * @author Bijan Ghasemi Afshar ( 100125463 )
 */
public class LibraryBook {
    
    // Declaring variables ( Fields )
    private enum Status {REFERENCE_ONLY, ON_LOAN, AVAILABLE_FOR_LENDING};
    Status currentStatus;
    private String author, title, libraryClassification;
    private int numberOfPages, timesBorrowed, pendingReservations;
    static int totalOnLoanBooks;
    
    
    /**
     * Constructor with arguments for a LibraryBook’s author(s),
     * title and number of pages
     * @param bookAuthor the names of the author(s) of this
     * LibraryBook
     * @param bookTitle the title of this LibraryBook
     * @param bookPages the number of pages of this
     * LibraryBook
     */
    public LibraryBook(String bookAuthor, String bookTitle, int bookPages)
    {
        author = bookAuthor;
        title = bookTitle;
        numberOfPages = bookPages;
        libraryClassification = null;
        timesBorrowed = 0;
        pendingReservations = 0;
        currentStatus = null;
    }
    
    // Getting the book author
    public String getAuthor()
    {
        return author;
    }
    
    // Getting the book title
    public String getTitle()
    {
        return title;
    }
    
    // Getting the number of book pages
    public int getNumberOfPages()
    {
        return numberOfPages;
    }
    
    // Getting the library classification
    public String getLibraryClassification()
    {
        return libraryClassification;
    }
    
    // Getting the number of times the book was borrowed
    public int getTimesBorrowed()
    {
        return timesBorrowed;
    }
    
    // Getting the cuurent status of a library book   
    public Status getCurrentStatus()
    {
        return currentStatus;
    }
    
    // Getting the pending reservations for a library book
    public int getPendingReservations()
    {
        return pendingReservations;
    }
    
    
    /**
     * A method to reset the Library classification of this
     * LibraryBook
     * @param bookClass the proposed new classification
     * @return true, if the proposed new
     * classification has at
     * least 3 characters to which
     * the Library classification is
     * reset.
     * false, otherwise.
     */
    public boolean setClassification(String bookClass)
    {
        boolean validClassification = false;
        if(bookClass.length() >= 3)
        {
            validClassification = true;
            libraryClassification = bookClass;
        }else{
            System.out.println("Not a proper classification (Must be more"
                    + " than two characters)");
        }      
        return validClassification;
    }
    
    // Setting the library book to reference only    
    public void setAsReferenceOnly()
    {
        if(currentStatus == null)
        {
            currentStatus = Status.REFERENCE_ONLY;
        }
    }
    
    // Setting  the library book to available for lending 
    public void setAsForLending()
    {
        if(currentStatus == null)
        {
            currentStatus = Status.AVAILABLE_FOR_LENDING;
        }
    }
    
    // Determining whether or not the book is available for lending
    public boolean isAvailable()
    {
        boolean available = false;
        if(currentStatus != Status.ON_LOAN &&
                currentStatus != Status.REFERENCE_ONLY)
        {
            available = true;
        }
        return available;
    }
    
    /**
     * If possible, reserves this LibraryBook.
     * This is only possible if this LibraryBook is currently on loan
     * and less than 3 reservations have been placed since this went
     * on loan.
     * @return true, if a new reservation has been made for this.
     * false, otherwise
     */
    public boolean reserveBook()
    {
        boolean reservation = false;
        if(currentStatus == Status.ON_LOAN &&
                pendingReservations < 3)
        {
            reservation = true;
            pendingReservations++;
        }
        return reservation;
    }
    
    // Borrowing the book
    public void borrowBook()
    {
        currentStatus = Status.ON_LOAN;
        if(pendingReservations > 0)
        {
            pendingReservations--;
        }
        timesBorrowed++;
        totalOnLoanBooks++;
    }
    
    // Returning the book
    public void returnBook()
    {
        currentStatus = Status.AVAILABLE_FOR_LENDING;                
        totalOnLoanBooks--;
    }
    
    // A to String method
    @Override
    public String toString()
    {
        
        String description = null;
        description = "\nTitle: "+title+
                "\nAuthor: " + author+
                "\nPages: " + numberOfPages+
                "\nClassificatoin: " + libraryClassification;
        return description;
    }
    
} // END of the CLASS
